import ipaddress
from netmiko import ConnectHandler  # type: ignore
from flask import Flask, render_template, request
from datetime import datetime
import re
import time

# Inicialização do Flask
app = Flask(__name__)

@app.route("/")
def index():
    return render_template("verificacao_cisco_a.html")  # Crie um arquivo HTML para o menu principal

# Função para validar IPs
def validar_ip(ip):
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        return False

# Função para executar comandos
def executar_comando(device_params, comando):
    try:
        print(f"Conectando ao dispositivo {device_params['host']}...")
        net_connect = ConnectHandler(**device_params)
        net_connect.enable()
        output = net_connect.send_command(comando)
        net_connect.disconnect()
        return output
    except Exception as e:
        return f"Erro ao executar o comando: {e}"
    

@app.route("/verificar_vpn", methods=["GET", "POST"])
def verificar_vpn():
    if request.method == "POST":
        ip_vpn = request.form.get("ip_vpn")
        device_ip = request.form.get("device_ip")
        username = request.form.get("username")
        password = request.form.get("password")

        if not validar_ip(ip_vpn):
            return "IP de VPN inválido. Por favor, insira um IP válido."

        device_params = {
            "device_type": "cisco_asa",
            "host": device_ip,
            "username": username,
            "password": password,
        }
        comando = f"show vpn-sessiondb detail l2l filter ipaddress {ip_vpn}"
        output = executar_comando(device_params, comando)
        return f"<pre>{output}</pre>" if output else "Erro ao verificar VPN."
    
    return render_template("verificar_cisco_vpn_asa.html")  # HTML com o formulário para entrada de dados

@app.route("/verificar_interfaces", methods=["GET", "POST"])
def verificar_interfaces():
    if request.method == "POST":
        device_ip = request.form.get("device_ip")
        username = request.form.get("username")
        password = request.form.get("password")

        if not validar_ip(device_ip):
            return "IP do dispositivo inválido."

        device_params = {
            "device_type": "cisco_asa",
            "host": device_ip,
            "username": username,
            "password": password,
        }
        comando = "show interface ip brief"
        output = executar_comando(device_params, comando)
        return f"<pre>{output}</pre>" if output else "Erro ao obter interfaces."
    
    return render_template("verificar_interfaces_cisco_asa.html")  # Formulário HTML

