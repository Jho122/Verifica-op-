import ipaddress
import netmiko  # type: ignore
from netmiko import ConnectHandler  # type: ignore
from getpass import getpass
from datetime import datetime
import os
import json
import re
import time  # Para pausas no loop
import hashlib
import random
import string
from flask import Flask, render_template, request, redirect, url_for

##############################################################################################
# Inicialização do Flask
app = Flask(__name__)

##############################################################################################
# Versionamento do código
VERSION = "1.2.0"
ERRO_LOG_PATH = r"C:\Users\jhonatas.rodrigues\Desktop\erro_log.txt"

def registrar_erro(mensagem):
    """Registra uma mensagem de erro no arquivo de log."""
    try:
        with open(ERRO_LOG_PATH, "a") as log_file:
            log_file.write(f"{datetime.now()} - {mensagem}\n")
    except Exception as e:
        print(f"Erro ao registrar o log: {e}")

##############################################################################################
# Função para executar comando em dispositivos
def executar_comando(device_params, comando):
    """Tenta conectar-se ao dispositivo e executar um comando."""
    try:
        print(f"Conectando ao dispositivo {device_params['host']}...")
        net_connect = ConnectHandler(**device_params)
        net_connect.enable()
        output = net_connect.send_command(comando)
        net_connect.disconnect()
        return output
    except netmiko.NetmikoTimeoutException as e:
        registrar_erro(f"Timeout ao conectar-se ao {device_params['host']}: {str(e)}")
        return "Erro: Tempo limite ao conectar-se ao dispositivo."
    except netmiko.NetmikoAuthenticationException as e:
        registrar_erro(f"Falha de autenticação no {device_params['host']}: {str(e)}")
        return "Erro: Falha de autenticação."
    except Exception as e:
        registrar_erro(f"Erro inesperado no {device_params['host']}: {str(e)}")
        return f"Erro inesperado: {str(e)}"

##############################################################################################
# Rota para conectar a dispositivos Cisco
@app.route("/conectar_cisco", methods=["GET", "POST"])
def conectar_cisco():
    if request.method == "POST":
        ip_dispositivo = request.form.get("ip_dispositivo")
        user = request.form.get("username")
        password = request.form.get("password")
        
        device = {
            'device_type': 'cisco_asa',
            'host': ip_dispositivo,
            'username': user,
            'password': password,
            'secret': password,
            'port': 22  # Altere se necessário
        }
        # Testar conexão e retornar resultado
        resultado = executar_comando(device, "show version")
        if resultado:
            return f"Conexão com Cisco estabelecida com sucesso. Resultado:\n{resultado}"
        else:
            return "Falha na conexão com Cisco. Verifique os detalhes e tente novamente."
    
    # Renderiza formulário para enviar os dados
    return render_template("conectar_cisco.html")

##############################################################################################
# Inicialização da aplicação
if __name__ == "__main__":
    app.run(debug=True)
